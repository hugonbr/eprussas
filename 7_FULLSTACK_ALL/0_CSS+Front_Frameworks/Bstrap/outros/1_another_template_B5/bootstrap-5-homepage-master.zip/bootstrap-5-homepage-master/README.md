# bootstrap-5-homepage
Marketing website homepage made with Boostrap 5 Alpha

Check it in action here: https://bootstrap5-marketing.netlify.app/

Vectors: https://www.freepik.com/

JQuery Scripts:
- Magnify Popup (https://dimsemenov.com/plugins/magnific-popup/)
- Isotope (http://isotope.metafizzy.co/)
- Owl Carousel 2 (https://owlcarousel2.github.io/OwlCarousel2/)
