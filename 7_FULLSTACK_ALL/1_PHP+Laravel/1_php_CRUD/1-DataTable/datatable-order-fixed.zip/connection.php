<?php
$con  = mysqli_connect('localhost','root','','datatable_example');
if(mysqli_connect_errno())
{
    echo 'Database Connection Error';
}
