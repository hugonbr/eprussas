from django.contrib import admin

from .models import Ativacao

admin.site.register(Ativacao)
