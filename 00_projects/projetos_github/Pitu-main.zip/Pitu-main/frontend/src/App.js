import Routes from "./routes";

const App = () => <Routes />;

export default App;
