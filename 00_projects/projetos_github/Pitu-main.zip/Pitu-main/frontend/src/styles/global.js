import styled from "styled-components";

export const BlockContainer = styled.div`
  display: block;
`;
