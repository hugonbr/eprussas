import styled from "styled-components";

export const NotFoundMessage404 = styled.p`
  font-size: 1.2rem;
  font-weight: 700;
  margin: 1rem;
`;
