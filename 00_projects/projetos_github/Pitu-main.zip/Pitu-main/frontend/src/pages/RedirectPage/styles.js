import styled from "styled-components";

export const RedirectParagraph = styled.p`
  font-size: 1.2rem;
  font-weight: 700;
  text-align: center;
`;
