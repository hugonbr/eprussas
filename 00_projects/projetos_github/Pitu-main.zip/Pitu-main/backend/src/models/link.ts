export type Link = {
  id?: number;
  url: string;
  code?: string;
  hits?: number;
};
